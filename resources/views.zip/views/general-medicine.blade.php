@php($title = "General Medicine/Internal Medicine | Bombay Hospital Indore")
@section('meta_desc') @endsection

@extends('layouts.default')
@section('content')

<!-- BREADCRUMB
			============================================= -->
<div class="division">
    <!-- <div class="container">
                <div class="row">
                    <div class="col">
                        <div class=" breadcrumb-holder">

                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ route('home')}}">Home</a></li>
                                    <li class="breadcrumb-item"><a href="#">Services</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Medical
                                    </li>
                                </ol>
                            </nav>

                            <h4 class="h4-sm steelblue-color">Cardiology</h4>

                        </div>
                    </div>
                </div> 
            </div>  -->
    <img src="{{ asset('/resources/assets/images/services/general-med-banner.jpg')}}" />
</div>

<div id="department-page" class="wide-60 department-page-section division">
    <div class="container">
        <div class="row">


            <!-- DEPARTMENT DETAILS -->
            <div class="col-lg-8">
                <div class="txt-block pr-30">


                    <!-- CONTENT BLOCK -->
                    <div class="content-block mb-40">
                        <!-- <div class="content-block-img">
                            <img class="img-fluid"
                                src="{{ asset('/resources/assets/images/services/general-medicine.jpg')}}"
                                alt="content-image">
                        </div> -->

                        <!-- <div id="pricing-2" class="pricing-section division">
                                    <div class="row pricing-row">

                                        <div class="col-md-12">
                                            <h5 class="h5-md steelblue-color">ECG</h5>

                                            <div class="pricing-table mb-40">
                                                <table class="table table-hover">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="row">Location</th>
                                                            <td>Ground Floor</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">For Appointment</th>
                                                            <td>0731-4771111 Extn. 2004</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Dept. Timings</th>
                                                            <td>Emergency-24 hrs</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">List of Consultants</th>
                                                            <td>Dr. Arun Jain</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <h5 class="h5-md steelblue-color">X-RAY</h5>

                                            <div class="pricing-table mb-40">
                                                <table class="table table-hover">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="row">Location</th>
                                                            <td>Basement</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">For Appointment</th>
                                                            <td>0731-4771111 Extn. 3006</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">Dept. Timings</th>
                                                            <td>Emergency-24 hrs</td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="row">List of Consultants</th>
                                                            <td>Dr. Mukesh Gupta</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->

                        <p>The Department of General Medicine/Internal Medicine at Bombay Hospital Indore has Indoor,
                            OPD and Intensive care facility available for both basic and highly advanced care for the
                            need of all types of patients. The OPD facility is well equipped consulting rooms as well
                            general OPD structure. The Indoor facility provides care right from deluxe rooms to general
                            wards. The hospital has multiple intensive care units to cater to all the requirements of
                            critically ill patients.</p>

                        <p>The Consultants in the department are highly qualified both in India as well as abroad with
                            extensive experience. Many are well known as leading doctors in India. The consultants are
                            supported by qualified resident doctors to provide round the clock supportive care to
                            patients.</p>

                        <p>The Internal Medicine department deals with patients with infections, undiagnosed rare
                            infections as well as common infections such as Malaria, Typhoid, Dengue, H1N1,
                            tuberculosis, HIV and other patients of undiagnosed fever. In the intensive care all types
                            of infection related complications such as multi-organ failure are effectively dealt with.
                            Patients with autoimmune disorder, genetic disorder, metabolic syndromes, rheumatological
                            diseases ,respiratory, gastrointestinal, neurological and haematological problems are
                            accurately diagnosed and managed in the department. Also, where multiple super-speciality
                            problems exist in same patients the physicians have special role to play in adjusting
                            medication and providing comprehensive care to the patients.</p>

                        <h5 class="h5-md steelblue-color">The department has facility for all diagnostic tests and
                            advanced specialised procedures.</h5>

                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Disease risk assessment, investigations and management
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Treatment of acute and chronic illnesses like digestive disorders asthma, pneumonia, and
                                other lung disorders.
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Treatment of communicable diseases like tuberculosis, typhoid and gastro enteritis
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Common ailments like sore throat, cold and flu, headaches, ear infections, urinary tract
                                infections, allergies and hepatitis
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Medical management of chronic diseases like obesity, metabolic syndrome, lipid disorders
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Management of lifestyle diseases like hypertension, diabetes and cardiovascular diseases
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Medical management of geriatric patients
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Health checks for adults, including high risk groups like diabetics
                            </p>
                        </div>
                        <div class="box-list">
                            <div class="box-list-icon"><i class="fas fa-angle-double-right"></i></div>
                            <p>Pre-operative assessment and management of patients undergoing surgery
                            </p>
                        </div>

                    </div> <!-- END CONTENT BLOCK -->
                </div>
            </div> <!-- END DEPARTMENT DETAILS -->

            <!-- SIDEBAR  -->
            <div class="col-lg-4">
                @include('includes.medical-sidebar')
            </div>

        </div> <!-- End row -->
    </div> <!-- End container -->
</div>

@stop