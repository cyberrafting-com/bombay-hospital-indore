     <!-- FOOTER-1
			============================================= -->
     <footer id="footer-1" class="bg-image wide-40 footer division">
         <div class="container-fluid" style="width:90%;">


             <!-- FOOTER CONTENT -->
             <div class="row">


                 <!-- FOOTER INFO -->
                 <div class="col-md-6 col-lg-2" style="padding: 0px;">
                     <div class="footer-info mb-40">

                         <!-- Footer Logo -->
                         <!-- For Retina Ready displays take a image with double the amount of pixels that your image will be displayed (e.g 360 x 80  pixels) -->
                         <img class="mb-10" src="{{ asset('/resources/assets/images/only-logo.png')}}"
                             alt="footer-logo">

                         <h5 class="h5-xs">Bombay Hospital Indore</h5>
                         <!-- Text -->
                         <p class="p-sm mt-20">Bombay Hospital Indore is the Preeminent NABH accredited Hospital in Madhya Pradesh.
                         </p>

                         <!-- Social Icons -->
                         <div class="footer-socials-links mt-20">
                             <ul class="foo-socials text-center clearfix">

                                 <li><a target="_blank" href="https://www.facebook.com/bhtrust/" class="ico-facebook"><i
                                             class="fab fa-facebook-f"></i></a></li>
                                 <!-- <li><a href="#" class="ico-twitter"><i class="fab fa-twitter"></i></a></li> -->
                                 <li><a target="_blank"
                                         href="https://www.instagram.com/bombay_hospital/?igshid=YmMyMTA2M2Y%3D"
                                         class="ico-instagram"><i class="fab fa-instagram"></i></a></li>
                                 <li><a target="_blank" href="https://www.youtube.com/channel/UCnzAVxg6PkwEhPKb10LMVNw"
                                         class="ico-youtube"><i class="fab fa-youtube"></i></a></li>
                             </ul>
                         </div>

                     </div>
                 </div>


                 <!-- FOOTER CONTACTS -->
                 <div class="col-md-6 col-lg-3">
                     <div class="footer-box mb-40">

                         <!-- Title -->
                         <h5 class="h5-xs">Contact Us</h5>

                         <!-- Address -->
                         <p><i class="fa-solid fa-location-dot"></i> Eastern Ring Road, Ring Road, IDA Scheme No.94/95,
                             Tulsi Nagar, Indore, Madhya Pradesh 452010</p>

                         <!-- Email -->
                         <p class="foo-email mt-20"><i class="fa-solid fa-envelope"></i> <a
                                 href="mailto:msofficebhi@gmail.com">msofficebhi@gmail.com</a>
                         </p>

                         <!-- Phone -->
                         <p class="foo-email mt-20"><i class="fa-solid fa-phone"></i> <a href="tel: +917314771111"> +91
                                 731 4771111</a></p>

                     </div>
                 </div>


                 <!-- FOOTER WORKING HOURS -->
                 <div class="col-md-6 col-lg-2">
                     <div class="footer-box mb-40">

                         <!-- Title -->
                         <h5 class="h5-xs">Reach us</h5>

                         <a target="_blank" href="https://goo.gl/maps/NCN77RVqWjNMEmBJ8"
                             class="btn btn__primary btn__link mr-30 mb-20">
                             <i class="fa-solid fa-arrow-right mr-10"></i> <span>Get Directions</span>
                         </a>
                         <a target="_blank" href="tel: 07314771111" class="btn btn__primary btn__link mr-30 mb-20">
                             <i class="fa-solid fa-arrow-right mr-10"></i> <span>In Emergency</span>
                         </a>
                         <a href="#" class="btn btn__primary btn__link mr-30 mb-20">
                             <i class="fa-solid fa-arrow-right mr-10"></i> <span>Appointment</span>
                         </a>
                     </div>
                 </div>


                 <!-- FOOTER PHONE NUMBER -->
                 <div class="col-md-6 col-lg-5">
                     <div class="footer-box mb-40">

                         <!-- Title -->
                         <h5 class="h5-xs">Know About us</h5>

                         <div class="youtube-footer">
                             <iframe width="100%" height="250" src="https://www.youtube.com/embed/v-H6IZfaBWQ"
                                 title="Bombay Hospital Documentary in Hindi" frameborder="0"
                                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                 allowfullscreen></iframe>
                         </div>

                     </div>
                 </div>


             </div> <!-- END FOOTER CONTENT -->


             <!-- FOOTER COPYRIGHT -->
             <div class="bottom-footer">
                 <div class="row">
                     <div class="col-md-12">
                         <p class="footer-copyright">&copy; 2023 <span>Bombay Hospital Indore</span>. All Rights
                             Reserved</p>
                     </div>
                 </div>
             </div>


         </div> <!-- End container -->
     </footer> <!-- END FOOTER-1 -->

     <div class="navbar-fixed-bottom d-lg-none d-xl-none d-md-none d-sm-none col-xs-12 "
         style="width:90%;text-align: center;position: fixed;right: 0;bottom: 0;left: 0;padding: 0px;text-align: center;z-index:100; margin-bottom: 5px;">
         <div class="row">

             <a href="{{ route('contact')}}" style="color:white; width: 100%;">
                 <div class="d-lg-none d-xl-none d-md-none d-sm-none " style="background-color: #0c9ab3; margin-top: 6px; padding: 15px 20px; margin-left: 20px; font-size: 20px;border-top-right-radius: 40px;border-bottom-right-radius: 40px;">
                     <i style="margin-right: 10px;" class="fa-regular fa-calendar-check"></i>Book an Appointment
                 </div>
             </a>
         </div>
     </div>


     <!-- EXTERNAL SCRIPTS
		============================================= -->
     <script src="{{ asset('/resources/assets/js/jquery-3.3.1.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/bootstrap.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/modernizr.custom.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.easing.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.appear.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.stellar.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/menu.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/sticky.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.scrollto.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/materialize.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/owl.carousel.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.magnific-popup.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/imagesloaded.pkgd.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/isotope.pkgd.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/hero-form.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/contact-form.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/comment-form.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/appointment-form.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.datetimepicker.full.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.validate.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/jquery.ajaxchimp.min.js')}}"></script>
     <script src="{{ asset('/resources/assets/js/wow.js')}}"></script>

     <!-- Custom Script -->
     <script src="{{ asset('/resources/assets/js/custom.js')}}"></script>

     <script>
new WOW().init();
     </script>


     <script src="{{ asset('/resources/assets/js/changer.js')}}"></script>
     <script defer src="{{ asset('/resources/assets/js/styleswitch.js')}}"></script>