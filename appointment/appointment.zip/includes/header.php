   <!-- top header start-->
    <div class="container">
        <div class="row"> 
            <div class="col-lg-4 col-md-4 col-12" style="padding:0px; float:left">
                <a href="https://www.bombayhospitalindore.com/"><img
                        src="http://www.bombayhospitalindore.com/wp-content/uploads/2014/11/logo11.png"
                        alt="Bombay Hospital" class="img-responsive" width="auto%;">
                    <h6 class="logo_heading">Bombay Hospital Indore</h6>
                </a>
            </div>
            <div class="col-lg-8 col-md-8 col-12 top-links">
                <ul class="top-menu">
                        <li><a href="//www.bombayhospitalindore.com/transplant-facility-available/" class="top-txt">Transplant
                                Facilities Available</a></li>
                        <li><a href="https://www.bombayhospitalindore.com/executive-checkup-schemes/" class="top-txt">Executive
                                Health Schemes</a>
                        </li>

                        <li><a href="https://www.bombayhospitalindore.com/photo_gallery/" class="top-txt">Photo
                                Gallery</a></li>
                        <li><a href="https://www.bombayhospitalindore.com/downloads/" class="top-txt">Downloads</a></li>
                        <li><a href="https://www.bombayhospitalindore.com/contact-us/" class="top-txt">Contact
                                Us</a></li>
                        <li><a href="https://www.bombayhospitalindore.com/patient-stories/" class="top-txt">Patient
                                Stories</a></li>
                        <li><a href="https://www.bombayhospitalindore.com/stents-pricing/" class="top-txt unset-border">Stents
                                Pricing</a></li>
                        <!--<li><a href="https://www.bombayhospitalindore.com/appointment/doctor_appointment.php" class="top-txt">Appointment</a></li>-->
                    </ul>
                <div class="emergency"><span>Emergency Number : </span>
                    <h4 class="number">0731-4771111
                        <!--0731-4077000-->
                    </h4>
                </div>
            </div>  
        </div>
    </div>

    <!-- top header end-->

 <!-- menubar start-->
    <nav class="bar-top-menu">
        <ul class="top-menu">
            <li class="active"><a href="https://www.bombayhospitalindore.com/">Home</a></li>

            <li><a href="https://www.bombayhospitalindore.com/about-hospital/"><span>About Us</span></a>
                <ul>
                    <li><a href="https://www.bombayhospitalindore.com/founder/">Founders</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/history/">History</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/hospital-location/">Hospital Location</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/management-board/">Management Board</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/vision-mission-motto/">Vision Mission &#038;
                            Motto</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/chairmans-message/">Philosophy</a></li>


                </ul>
            </li>
            <li><a href="https://www.bombayhospitalindore.com/services/"><span>Services</span></a>
                <ul>

                    <li><a href="https://www.bombayhospitalindore.com/diagnostic-facilities/"><span>Diagnostic</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/blood-transfusion-service-component-lab/">Blood
                                    Transfusion Service – Component Lab</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/cath-lab/">Cath Lab</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/ecg_echo_stress_holter/">ECG, Echo/Stress
                                    &#038; Holter</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/eeg-emg/">EEG, EMG</a></li>
                          
                            <li><a href="https://www.bombayhospitalindore.com/histopathology-department/">Histopathology
                                    Department</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/mri-ct-scan/">MRI &#038; CT Scan</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/pathology/">Pathology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/pulmonary-function-lab/">Pulmonary
                                    Function Lab</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/ultrasound/">Ultrasound</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/xray/">X’RAY</a></li>
                        </ul>
                    </li>
                    <li><a href="https://www.bombayhospitalindore.com/cardiology/"><span>Medical</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/cardiology/">Cardiology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/chest-medicine-pulmonary-function-lab/">Chest
                                    Medicine</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/gastroenterology/">Gastroenterology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/general-medicine/">General Medicine</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/neonatology-and-intensive-pediatrics">Neonatology
                                    and Intensive Pediatrics</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/nephrology/">Nephrology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/neurology/">Neurology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/surgical-oncology-medical-oncology/">Oncology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/paediatrics/">Paediatrics</a></li>
                        </ul>
                    </li>
                    <li> <a href="https://www.bombayhospitalindore.com/admission/"><span>Round the clock</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/admission/">Admission</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/ecg-x-ray/">ECG &#038; X-Ray</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/emergency-casualty/">Emergency &#038;
                                    Casualty</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/path_lab/">Path Lab</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/pharmacy/">Pharmacy</a></li>
                        </ul>
                    </li>
                    <li><a href="https://www.bombayhospitalindore.com/bombay-hospital-institute-of-medical-sciences-bhims/"><span>Health
                            Liberary</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/health-tips/">Health Tips</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/health-education/">Health Education</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/tests-and-procedures/">Tests and
                                    Procedures</a></li>
                        </ul>
                    </li>
                    <li><a href="https://www.bombayhospitalindore.com/cardiovascular-thoracic-surgery/"><span>Surgical</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/cardiovascular-thoracic-surgery/">Cardiovascular
                                    &#038; Thoracic Surgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/ear-nose-throat-ent/">Ear / Nose / Throat</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/general-surgery-2/">General Surgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/kidney-transplant/">Kidney Transplant</a></li>

                            <li><a href="https://www.bombayhospitalindore.com/gastrointestinallaproscopic-and-hepato-pancreatico-biliary-surgery/">Gastrointestinal,laproscopic
                                    and Hepato-Pancreatico-Biliary surgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/neurosurgery/">Neurosurgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/obstetrics-_and-_gynaecology_surgery/">Obstetrics and Gynaecology Surgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/ophthalmology-3/">Ophthalmology</a></li>

                            <li><a href="https://www.bombayhospitalindore.com/orthopedics/">Orthopedics</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/plastic-and-cosmetic-surgery/">Plastic
                                    Surgery</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/surgical-oncology-medical-oncology/">Surgical
                                    Oncology</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/urology/">Urology</a></li>
                        </ul>
                    </li>
                    <li><a href="https://www.bombayhospitalindore.com/diabetic-clinic/"><span>Therapeutic</span></a>
                        <ul>
                            <li><a href="https://www.bombayhospitalindore.com/dialysis-unit-artifical-kidney-unit/">Dialysis
                                    Unit (Artifical Kidney Unit)</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/dietician/">Dietician and Nutrition
                                    Clinic</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/doctors-scorecard/">Doctor’s
                                    Scorecard</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/lithotripsy/">Lithotripsy</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/physiotherapy/">Physiotherapy</a></li>
                            <li><a href="https://www.bombayhospitalindore.com/executive-checkup-schemes/">Preventive
                                    Health Care</a></li>
                        </ul>
                    </li>



                </ul>
            </li>
            <li><a href="https://www.bombayhospitalindore.com/admissions/">In-Patient Guide</a>
                <ul>
                    <li><a href="https://www.bombayhospitalindore.com/admission-procedures/">Admission Procedures</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/billing/">Billing</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/insurancemediclaim/">Insurance/Mediclaim</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/important-telephone-numbers/">Important Telephone
                            Numbers</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/meals/">Meals</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/room-facilities/">Room Facilities</a></li>
                    <li><a href="https://www.bombayhospitalindore.com/visiting-hours/">Visiting Hours</a></li>


                </ul>
            </li>

            <li><a href="https://www.bombayhospitalindore.com/consultants/">Panel of Consultants</a></li>
            <li><a href="https://www.bombayhospitalindore.com/why-bombay-hospital/">Why Bombay Hospital</a></li>
            <li><a href="https://www.bombayhospitalindore.com/feedback-suggestions/">Feedback / Suggestions</a></li>
            <li><a href="http://www.bombayhospitalindore.com/bpl_portal/index.php">BPL Portal</a></li>
            <li><a href="https://www.bombayhospitalindore.com/bmw/">BMW</a></li>
            <li><a href="https://walkinto.in/tour/WJN7ftm4dX-1lNQGYmNuX">Virtual Tour</a></li>
        </ul>
    </nav>
    <!-- menubar end-->
