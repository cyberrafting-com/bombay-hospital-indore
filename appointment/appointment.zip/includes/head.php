<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Bombay Hospital | Bombay Hospital</title>
    <link rel="profile" href="http://gmpg.org/xfn/11" />
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="pingback" href="https://www.bombayhospitalindore.com/xmlrpc.php" />
    <link rel="icon" href="http://itpark.in/bombayhospital/wp-content/uploads/2014/08/favicon.ico"
        type="image/x-icon" />
    <link rel="shortcut icon" href="http://itpark.in/bombayhospital/wp-content/uploads/2014/08/favicon.ico"
        type="image/x-icon" />
    <link rel="alternate" type="application/rss+xml" title="Bombay Hospital &raquo; Feed"
        href="https://www.bombayhospitalindore.com/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Bombay Hospital &raquo; Comments Feed"
        href="https://www.bombayhospitalindore.com/comments/feed/" />
    <link rel="stylesheet" href="../appointment/assets/css/new-style.css">
    <link rel="stylesheet" href="../appointment/assets/css/style.css">