
    <footer>


        <div class="footer">
            <div class="container" style="padding:0px;">
                <div class="row">
                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Diagnostics</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/blood-transfusion-service-component-lab/">Blood
                                                Transfusion Service</a></li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/cath-lab/">Cath Lab</a></li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/ecg_echo_stress_holter/">ECG, Echo/Stress
                                                & Holter</a></li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/eeg-emg/">EEG & EMG</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/histopathology-department/">Histopathology</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/mri-ct-scan/">MRI & CT
                                                Scan</a></li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/pathology/">Pathology</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/pulmonary-function-lab/">Pulmonary
                                                Function Lab</a></li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/ultrasound/">Ultrasound</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="http://bombayhospitalindore.com/?page_id=1117">Urodynamics</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/xray/">X’RAY</a></li>

                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Medical</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/cardiology/">Cardiology</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/chest-medicine-pulmonary-function-lab/">Chest
                                                Medicine</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/gastroenterology/">Gastroentrology</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/general-medicine/">General
                                                Medicine</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/neonatology-and-intensive-pediatrics">Neonatology and
                                                Intensive Pediatrics</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/nephrology/"> Nephrology</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/neurology/">Neurology</li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/surgical-oncology-medical-oncology/">Oncology</a>
                                        </li>
                                        <li> <i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/paediatrics/">Paediatrics</a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Round the clock</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/admission/">Admissions</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/ecg-x-ray/"> ECG & X-Ray</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/emergency-casualty/">Emergency &
                                                Casualty</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/path_lab/">Path Lab</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/pharmacy/">Pharmacy</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Health Library</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/health-tips/">Health Tips</a>
                                        <li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/health-education/">Health
                                                Education</a>
                                        <li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/tests-and-procedures/">Tests and
                                                Procedures</a>
                                        <li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Surgical</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/cardiovascular-thoracic-surgery/">Cardiovascular &
                                                Thoracic Surgery</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/ear-nose-throat-ent/">Ear / Nose /
                                                Throat (ENT)</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/general-surgery-2/">General
                                                Surgery</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/kidney-transplant/">Kidney
                                                Transplant</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/neurosurgery/">Neuro-Surgery</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/obstetrics-_and-_gynaecology_surgery/">Obstetrics and
                                                Gynaecology Surgery</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/ophthalmology-3/">Opthalmology</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/orthopedics/">Orthopaedics</a></i>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/plastic-and-cosmetic-surgery/">Plastic
                                                Surgery</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/surgical-oncology-medical-oncology/">Surgical
                                                Oncology</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/urology/">Urology</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/gastrointestinallaproscopic-and-hepato-pancreatico-biliary-surgery/">Gastrointestinal,
                                                Laproscopic and Hepato-Pancreatico-Biliary Surgery</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 column">
                        <div class="row">
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Therapeutic</h4>
                                <div class="textwidget">
                                    <ul>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/dialysis-unit-artifical-kidney-unit/">Dialysis Unit
                                                (AKU)</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/dietician/">Dietician and
                                                Nutrition Clinic</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/doctors-scorecard/">Doctor’s
                                                Scorecard</a></li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/lithotripsy/"> Lithotripsy</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/physiotherapy/">Physiotherapy</a>
                                        </li>
                                        <li><i class="fa fa-angle-double-right"></i><a href="https://www.bombayhospitalindore.com/executive-checkup-schemes/">Preventive
                                                Health Checkup (EHS)</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <div class="container footer-nav ">
        <div class="row">
            <div class="col-md-12">

                <div class="col-md-6">
                    <div class="counter-block">

                        <img src="http://counter5.01counter.com/private/freecounterstat.php?c=a7c913d2edfeaa93cfadc8cabcd59420"
                            border="0" title="website hits counter" alt="website hits counter">
                        <b>Visitors</b>
                    </div>
                </div>
                <div class="col-md-6 foot--txt">
                    <div class="">
                        <p class=" credit">© 2022 <a href="https://www.bombayhospitalindore.com/" class="footer-txt"
                                title="Bombay Hospital" rel="home">Bombay Hospital</a>&nbsp;&nbsp;&nbsp;<span
                                class="brand-note">Developed By : <a href="http://infocratsweb.com/" class="footer-txt"
                                    target="_blank">Infocrats Web Solution</a></span></p>

                    </div>
                </div>

            </div>

        </div>
    </div>
